import { IProduct } from "src/common";

export class ProductResponse {
    product: IProduct;
}
