import { RoleEnum } from "src/common";

export const endPoint = {
    create:[RoleEnum.admin,RoleEnum.superAdmin]
}