import { LoginCredentialsResponse } from "src/common";

export class LoginResponse{
    credentials: LoginCredentialsResponse

}