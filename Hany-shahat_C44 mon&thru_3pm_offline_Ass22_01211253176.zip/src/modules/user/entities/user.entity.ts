import { IResponse, IUser } from "src/common";

export class ProfileResponse {
 profile: IUser;
}