export class LoginCredentialsResponse{
    access_token: string;
    refresh_token: string;
}