import { AthenticationGuard } from './athentication.guard';

describe('AthenticationGuard', () => {
  it('should be defined', () => {
    expect(new AthenticationGuard()).toBeDefined();
  });
});
