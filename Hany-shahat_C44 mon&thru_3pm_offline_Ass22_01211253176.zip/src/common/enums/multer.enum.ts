export enum StorageEnum{
    disk = 'disk',
    memory='memory',
}
export enum FolderEnum{
    Brand = 'Brand',
    Category = 'Category',
    Product='Product',
}