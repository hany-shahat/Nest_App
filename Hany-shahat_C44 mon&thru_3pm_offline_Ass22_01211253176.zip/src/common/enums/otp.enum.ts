export enum OtpEnum{
    ConfirmEmail = "Confirm_Email",
    ResetPassword = "Reset_Password",
    TwoStepsVerification="Two_Steps_Verification",
}